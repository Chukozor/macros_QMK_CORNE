#pragma once

bool layer_is_default(void);
bool layer_is_not_default(void);
bool no_mods(void);