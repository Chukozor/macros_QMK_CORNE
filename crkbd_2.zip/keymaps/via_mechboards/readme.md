# Default Via keymap for the Corne R2G by Mechboards UK

Corne R2G is an edition of the classic CRKBD by foostan remade to feature full smd assembly

In this folder can be found the default via enabled keymap that can be in conjunction with the mechboards R2G PCB.

Flash example for this Keymap:  
```sh
qmk flash -kb crkbd/r2g -km via_mechboards
```
