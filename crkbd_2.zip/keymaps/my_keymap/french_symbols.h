#pragma once

void tap_e_grave(void);
void tap_e_aigue(void);
void tap_e_circ(void);

void tap_c_ced(void);

void tap_a_grave(void);
void tap_a_circ(void);

void tap_i_circ(void);
void tap_i_trema(void);

void tap_u_grave(void);
void tap_u_circ(void);

void tap_o_circ(void);
void tap_point_virgule(void);

