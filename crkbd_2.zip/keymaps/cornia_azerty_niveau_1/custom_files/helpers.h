#pragma once

bool is_accent_layer(void);
bool is_shift_layer(void);
bool is_maj_layer(void);
bool is_caps_layer(void);
bool is_colemak_layer(void);